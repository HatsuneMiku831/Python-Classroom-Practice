# ch11_10_1.py
val = None
if val:
    print("I love Java")
else:
    print("I love Python")




