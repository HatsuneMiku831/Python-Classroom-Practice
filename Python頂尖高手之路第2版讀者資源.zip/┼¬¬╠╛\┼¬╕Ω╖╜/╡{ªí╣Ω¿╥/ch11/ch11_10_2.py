# ch11_10_2.py
val = None
print("I love Java" if val else "I love Python")



