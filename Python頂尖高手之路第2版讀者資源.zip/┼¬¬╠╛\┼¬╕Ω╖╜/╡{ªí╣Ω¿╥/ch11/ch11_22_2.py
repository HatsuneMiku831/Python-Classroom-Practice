# ch11_22_2.py
def insertChar(letter, myList=None):
    if myList == None:
        myList = []
    myList.append(letter)
    print(myList)

insertChar('x')
insertChar('y')




