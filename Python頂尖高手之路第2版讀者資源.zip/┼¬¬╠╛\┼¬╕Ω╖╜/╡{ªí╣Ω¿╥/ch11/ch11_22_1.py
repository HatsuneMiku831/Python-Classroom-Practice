# ch11_22_1.py
def insertChar(letter, myList=[], inList=[1,2]):
    myList.append(letter)
    inList.append(letter)
    print(myList)
    print(inList)

insertChar('x')
insertChar('y')






