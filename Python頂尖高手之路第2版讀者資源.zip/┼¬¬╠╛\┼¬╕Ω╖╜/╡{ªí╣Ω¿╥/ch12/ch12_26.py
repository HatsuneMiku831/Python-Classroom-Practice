# ch12_26.py
import ch12_24

