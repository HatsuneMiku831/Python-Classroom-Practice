# ch12_28.py
class Name:
    def __init__(self, name):
        self.name = name

a = Name('Hung')
print(a)


