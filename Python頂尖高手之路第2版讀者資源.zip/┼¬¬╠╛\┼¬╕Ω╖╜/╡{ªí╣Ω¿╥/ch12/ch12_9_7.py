# ch12_9_7.py
class Pizza():
    @staticmethod
    def demo():
        print("I like Pizza")

Pizza.demo()



    











        
        
