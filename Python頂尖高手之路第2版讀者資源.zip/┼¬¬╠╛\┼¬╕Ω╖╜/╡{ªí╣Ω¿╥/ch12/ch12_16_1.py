# ch12_16_1.py
class Person():
    def interest(self):
        print("Smiling is my interest")

hung = Person()
hung.interest()




        
        
