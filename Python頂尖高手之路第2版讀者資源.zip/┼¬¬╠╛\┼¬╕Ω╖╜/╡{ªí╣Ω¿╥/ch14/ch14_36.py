# ch14_36.py
import shutil

shutil.move('data36.txt', 'D:\\Python\\out36.txt')  # out36.txt不存在



