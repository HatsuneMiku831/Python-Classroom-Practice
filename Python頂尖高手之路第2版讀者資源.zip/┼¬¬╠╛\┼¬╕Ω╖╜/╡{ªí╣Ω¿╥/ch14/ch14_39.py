# ch14_39.py
import shutil

shutil.rmtree('dir39')  



