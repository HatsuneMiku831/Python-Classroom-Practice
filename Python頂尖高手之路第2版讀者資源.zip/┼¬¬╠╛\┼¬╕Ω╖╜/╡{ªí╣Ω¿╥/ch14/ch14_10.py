# ch14_10.py
import os

files = ['ch14_1.py', 'ch14_2.py', 'ch14_3.py']
for file in files:
    print(os.path.join('D:\\Python\\ch14', file))   




