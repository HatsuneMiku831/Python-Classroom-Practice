# ch14_37.py
import shutil

shutil.move('dir37', 'D:\\Python')  



