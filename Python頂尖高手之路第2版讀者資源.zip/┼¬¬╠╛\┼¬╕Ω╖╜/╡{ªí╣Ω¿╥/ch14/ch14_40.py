# ch14_40.py
import send2trash

send2trash.send2trash('data40.txt')  



