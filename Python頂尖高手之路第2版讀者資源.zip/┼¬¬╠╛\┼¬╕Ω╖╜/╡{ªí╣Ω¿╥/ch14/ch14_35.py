# ch14_35.py
import shutil

shutil.move('data35.txt', 'out35.txt')  # 更改檔案名稱



