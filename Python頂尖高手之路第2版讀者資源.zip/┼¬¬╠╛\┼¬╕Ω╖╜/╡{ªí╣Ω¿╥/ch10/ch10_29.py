# ch10_29.py
A = {n for n in range(1,100,2) if n % 11 == 0}
print(type(A))
print(A)











