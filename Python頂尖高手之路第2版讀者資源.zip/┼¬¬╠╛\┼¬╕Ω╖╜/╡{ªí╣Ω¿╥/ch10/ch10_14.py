# ch10_14.py
countries = {'Japan', 'China', 'France'}
print("刪除前的countries集合 ", countries)
countries.remove('Japan')
print("刪除後的countries集合 ", countries)

