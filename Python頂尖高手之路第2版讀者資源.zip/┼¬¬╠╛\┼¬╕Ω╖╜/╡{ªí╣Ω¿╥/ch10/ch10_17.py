# ch10_17.py
animals = {'dog', 'cat', 'bird'}
print("刪除前的animals集合 ", animals)
ret_element = animals.pop( )        
print("刪除後的animals集合 ", animals)
print("所刪除的元素是      ", ret_element)


