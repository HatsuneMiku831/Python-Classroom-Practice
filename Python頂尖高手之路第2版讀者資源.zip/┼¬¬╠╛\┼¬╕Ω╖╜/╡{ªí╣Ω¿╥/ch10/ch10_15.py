# ch10_15.py
animals = {'dog', 'cat', 'bird'}
print("刪除前的animals集合 ", animals)
animals.remove('fish')        # 刪除不存在的元素產生錯誤
print("刪除後的animals集合 ", animals)


