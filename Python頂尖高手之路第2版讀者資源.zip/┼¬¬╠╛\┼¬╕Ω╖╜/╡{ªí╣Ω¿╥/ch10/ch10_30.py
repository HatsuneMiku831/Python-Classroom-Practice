# ch10_30.py
word = 'deepstone'
alphabetCount = {alphabet:word.count(alphabet) for alphabet in set(word)}
print(alphabetCount)











