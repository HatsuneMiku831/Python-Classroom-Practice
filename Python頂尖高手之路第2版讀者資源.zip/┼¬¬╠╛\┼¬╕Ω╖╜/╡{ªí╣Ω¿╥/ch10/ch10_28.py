# ch10_28.py
A = {n for n in range(1,100,2)}
print(type(A))
print(A)












