# ch10_18.py
states = {'Mississippi', 'Idaho', 'Florida'}
print("刪除前的states集合    ", states)
states.clear( )
print("刪除前的states集合    ", states)

# 測試刪除空集合
empty_set = set( )
print("刪除前的empty_set集合 ", empty_set)
states.clear( )
print("刪除前的empty_set集合 ", empty_set)


