# ch10_10.py 
math = {'Kevin', 'Peter', 'Eric'}       # 設定參加數學夏令營成員
print("列印參加數學夏令營的成員")
for name in math:
    print(name)






