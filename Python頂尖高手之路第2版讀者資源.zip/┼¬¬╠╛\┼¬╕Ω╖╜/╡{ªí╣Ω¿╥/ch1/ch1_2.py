# ch1_2.py
print("Hello! Python")   # 列印字串
