"""
程式實例ch1_4.py
作者:洪錦魁
使用三個雙引號當作註解
"""
print("Hello! Python")   # 列印字串
