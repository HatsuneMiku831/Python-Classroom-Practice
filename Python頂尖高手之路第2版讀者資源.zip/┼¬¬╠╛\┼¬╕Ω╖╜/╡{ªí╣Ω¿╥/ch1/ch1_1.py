print('Hello! Python')
