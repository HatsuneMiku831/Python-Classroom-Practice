# ch15_24.py
import logging

logging.basicConfig(level=logging.DEBUG, format='')
logging.debug('logging message, DEBUG')
logging.info('logging message, INFO')
logging.warning('logging message, WARNING')
logging.error('logging message, ERROR')
logging.critical('logging message, CRITICAL')


