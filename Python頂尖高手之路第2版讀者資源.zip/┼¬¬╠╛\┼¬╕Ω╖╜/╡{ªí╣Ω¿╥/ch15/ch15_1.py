# ch15_1.py
def division(x, y):
    return x / y

print(division(10, 2))      # 列出10/2
print(division(5, 0))       # 列出5/0
print(division(6, 3))       # 列出6/3



