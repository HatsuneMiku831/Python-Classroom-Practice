# ch13_47_1.py
import itertools

x = ['a', 'b', 'c']
r = 2
y = itertools.combinations(x, r)
print(list(y))
















