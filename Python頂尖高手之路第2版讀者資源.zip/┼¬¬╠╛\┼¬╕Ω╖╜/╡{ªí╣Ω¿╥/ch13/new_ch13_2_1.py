# new_ch13_2_1.py
import ch13_1         # 導入模組ch13_1.py

ch13_1.make_icecream('草莓醬')
ch13_1.make_icecream('草莓醬', '葡萄乾', '巧克力碎片')
ch13_1.make_drink('large', 'coke')

