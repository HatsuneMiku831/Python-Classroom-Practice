# ch13_7.py
import makefood as m        # 導入模組makefood.py的替代名稱m

m.make_icecream('草莓醬')
m.make_icecream('草莓醬', '葡萄乾', '巧克力碎片')
m.make_drink('large', 'coke')

