# ch13_27_1.py
import sys

print(sys.platform)









