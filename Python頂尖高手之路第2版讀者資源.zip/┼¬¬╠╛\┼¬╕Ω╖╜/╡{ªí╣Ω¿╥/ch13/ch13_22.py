# ch13_22.py
import time                         # 導入模組time

print(time.asctime())               # 列出目前系統時間 



