# ch13_21.py
import time                        # 導入模組time

fruits = ['蘋果', '香蕉', '西瓜', '水蜜桃', '百香果']
for fruit in fruits:
    print(fruit)
    time.sleep(1)                   # 暫停1秒





