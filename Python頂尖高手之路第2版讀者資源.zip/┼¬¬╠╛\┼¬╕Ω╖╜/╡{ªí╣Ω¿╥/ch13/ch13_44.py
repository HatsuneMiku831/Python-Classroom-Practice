# ch13_44.py
import sys
from pprint import pprint
print("使用print")
print(sys.path)
print("使用pprint")
pprint(sys.path)














