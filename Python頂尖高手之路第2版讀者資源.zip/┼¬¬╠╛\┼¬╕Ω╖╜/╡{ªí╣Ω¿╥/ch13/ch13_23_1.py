# ch13_23_1.py
import time                         # 導入模組time

print(time.ctime())




