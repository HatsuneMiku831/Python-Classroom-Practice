# ch13_43.py
from collections import deque

def palindrome(word):
    return word == word[::-1]

print(palindrome("x"))
print(palindrome("abccba"))
print(palindrome("radar"))
print(palindrome("python"))


















