# ch13_31.py
import calendar

print(calendar.month(2020,1))





