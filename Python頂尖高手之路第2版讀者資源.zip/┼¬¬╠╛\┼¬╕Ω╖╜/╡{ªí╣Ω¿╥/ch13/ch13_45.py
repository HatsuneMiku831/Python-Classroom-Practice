# ch13_45.py
import itertools
for i in itertools.chain([1,2,3],('a','d')):
    print(i)















