# ch13_2.py
import makefood         # 導入模組makefood.py

makefood.make_icecream('草莓醬')
makefood.make_icecream('草莓醬', '葡萄乾', '巧克力碎片')
makefood.make_drink('large', 'coke')

