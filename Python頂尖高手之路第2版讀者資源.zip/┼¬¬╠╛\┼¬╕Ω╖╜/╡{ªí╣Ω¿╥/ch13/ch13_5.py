# ch13_5.py
from makefood import *      # 導入模組makefood.py所有函數

make_icecream('草莓醬')
make_icecream('草莓醬', '葡萄乾', '巧克力碎片')
make_drink('large', 'coke')         

