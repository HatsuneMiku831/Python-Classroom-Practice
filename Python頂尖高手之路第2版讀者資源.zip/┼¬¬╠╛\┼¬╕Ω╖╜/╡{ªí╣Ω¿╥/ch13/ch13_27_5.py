# ch13_27_5.py
import sys
print("命令列參數 : ", sys.argv)



