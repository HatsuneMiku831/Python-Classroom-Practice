# ch13_32.py
import calendar

print(calendar.calendar(2020))





