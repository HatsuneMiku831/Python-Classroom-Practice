# ch13_6.py
# 使用icecream替代make_icecream函數名稱
from makefood import make_icecream  as icecream 

icecream('草莓醬')
icecream('草莓醬', '葡萄乾', '巧克力碎片')

