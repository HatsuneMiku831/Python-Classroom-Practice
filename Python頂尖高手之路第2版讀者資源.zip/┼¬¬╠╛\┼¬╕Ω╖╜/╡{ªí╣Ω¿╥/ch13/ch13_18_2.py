# ch13_18_2.py
import random                               # 導入模組random

for i in range(5):
    print("uniform(1,10) : ", random.uniform(1, 10))















