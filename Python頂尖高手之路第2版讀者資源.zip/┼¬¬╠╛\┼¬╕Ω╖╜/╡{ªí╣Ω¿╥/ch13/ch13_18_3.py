# ch13_18_3.py
import random

for i in range(5):
    print(random.random())
    





