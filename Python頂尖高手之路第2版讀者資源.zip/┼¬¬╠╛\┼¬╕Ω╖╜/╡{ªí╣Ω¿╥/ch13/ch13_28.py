# ch13_28.py
import keyword

print(keyword.kwlist)


