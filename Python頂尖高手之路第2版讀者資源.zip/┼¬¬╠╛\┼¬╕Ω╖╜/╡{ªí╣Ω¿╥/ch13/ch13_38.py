# ch13_38.py
from collections import Counter

fruits = ["apple","orange","apple"]
fruitsdict = Counter(fruits)
print(fruitsdict)


















