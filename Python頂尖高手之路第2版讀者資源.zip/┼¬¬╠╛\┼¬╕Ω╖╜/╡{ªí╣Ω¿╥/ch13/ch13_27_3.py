# ch13_27_3.py
import sys

print(sys.getwindowsversion())








