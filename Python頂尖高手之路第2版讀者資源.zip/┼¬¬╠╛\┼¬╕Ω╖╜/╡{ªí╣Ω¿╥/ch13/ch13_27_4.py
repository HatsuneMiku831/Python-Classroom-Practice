# ch13_27_4.py
import sys

print(sys.executable)








