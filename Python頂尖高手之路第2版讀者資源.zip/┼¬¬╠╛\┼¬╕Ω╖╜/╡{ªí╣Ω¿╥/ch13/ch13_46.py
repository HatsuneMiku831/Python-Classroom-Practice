# ch13_46.py
import itertools
for i in itertools.cycle(('a','b','c')):
    print(i)















