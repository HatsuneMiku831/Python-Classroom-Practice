# ch13_18_4.py
import random
random.seed(5)
for i in range(5):
    print(random.random())
    





