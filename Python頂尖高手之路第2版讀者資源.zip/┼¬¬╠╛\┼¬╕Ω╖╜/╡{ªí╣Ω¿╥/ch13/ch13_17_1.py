# ch13_17_1.py
import random                       # 導入模組random

for i in range(10):
    print(random.choice([1,2,3,4,5,6]), end=",")








