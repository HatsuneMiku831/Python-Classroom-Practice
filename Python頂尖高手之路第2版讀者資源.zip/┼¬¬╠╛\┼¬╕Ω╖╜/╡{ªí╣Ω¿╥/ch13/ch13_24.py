# ch13_24.py
import sys

print("目前Python版本是: ", sys.version)
print("目前Python版本是: ", sys.version_info)


