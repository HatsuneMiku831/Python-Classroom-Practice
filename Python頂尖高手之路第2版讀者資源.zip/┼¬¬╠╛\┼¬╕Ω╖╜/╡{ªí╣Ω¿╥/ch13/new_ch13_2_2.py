# new_ch13_2_2.py
import new_makefood         # 導入模組new_makefood.py

new_makefood.make_icecream('草莓醬')
new_makefood.make_icecream('草莓醬', '葡萄乾', '巧克力碎片')
new_makefood.make_drink('large', 'coke')

