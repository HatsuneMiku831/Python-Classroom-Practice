# ch13_27_2.py
import sys
for dirpath in sys.path:
    print(dirpath)












