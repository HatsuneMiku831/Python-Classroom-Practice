# ch13_4.py
# 導入模組makefood.py的make_icecream和make_drink函數
from makefood import make_icecream, make_drink  

make_icecream('草莓醬')
make_icecream('草莓醬', '葡萄乾', '巧克力碎片')
make_drink('large', 'coke')         

