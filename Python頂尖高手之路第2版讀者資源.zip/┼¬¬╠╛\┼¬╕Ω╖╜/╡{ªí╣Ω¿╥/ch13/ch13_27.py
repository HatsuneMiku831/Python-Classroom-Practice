# ch13_27.py
import sys

sys.stdout.write("I like Python")





