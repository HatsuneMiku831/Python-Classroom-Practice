# ex4_6.py
pin = input("請輸入坪數：")
meter = int(pin) * 3.305
print(f"坪數 {pin} 等於平方公尺 {meter:4.1f}")




