# ex13_10.py
import calendar

year = int(input("請輸入年份 : "))
month = int(input("請輸入月份 : "))
print(calendar.month(year, month))








