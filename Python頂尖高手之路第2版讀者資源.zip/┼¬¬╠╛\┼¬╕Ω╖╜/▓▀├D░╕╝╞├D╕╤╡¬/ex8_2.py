# ex8_2.py
bookclub = ('John','Peter','Curry','Mike','Kevin')
print("讀書會成員")
for people in bookclub:
    print(people)
bookclub[0] = 'Johnnason'
for people in bookclub:
    print(people)


