# ex3_6.py
code1 = '洪'
code2 = '錦'
code3 = '魁'
print("洪")
print(hex(ord(code1)))        # 輸出字元'洪'的Unicode碼值
print("錦")
print(hex(ord(code2)))        # 輸出字元'錦'的Unicode碼值
print("魁")
print(hex(ord(code3)))        # 輸出字元'魁'的Unicode碼值





