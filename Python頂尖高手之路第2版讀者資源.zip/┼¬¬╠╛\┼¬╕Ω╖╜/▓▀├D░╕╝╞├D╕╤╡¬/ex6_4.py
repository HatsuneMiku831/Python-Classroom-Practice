# ex6_4.py
cities = ['Taipei','Beijing','Tokyo','Chicago','Nanjing']
print(cities)
cities.append('London')
print(cities)
cities.insert(3,'Xian')
print(cities)
cities.remove('Tokyo')
print(cities)







    
