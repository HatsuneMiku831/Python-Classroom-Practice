# ex2_2.py
money = 50000 * 0.015 * 5
print("利息總和")
print(money)

