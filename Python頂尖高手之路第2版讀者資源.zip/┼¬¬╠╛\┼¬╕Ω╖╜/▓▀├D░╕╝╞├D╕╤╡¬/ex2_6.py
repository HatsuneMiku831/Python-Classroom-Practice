# ex2_6.py
PI = 3.14159
r = 20
height = 30
area = PI * r * r
volumn = height * area
print("圓柱體積:單位是立方公分")
print(volumn)




