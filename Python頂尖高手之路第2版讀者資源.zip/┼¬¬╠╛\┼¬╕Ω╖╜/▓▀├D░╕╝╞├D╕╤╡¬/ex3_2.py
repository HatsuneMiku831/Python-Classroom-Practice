# ex3_2.py
money = 100000 * ( 1 + 0.02 ) ** 10
print("10年後本金和")
print(int(money))


