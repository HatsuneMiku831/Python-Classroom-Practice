# ex7_8.py
n1 = [1,2,3,4,5]
n2 = [1,2,3,4,5]
result = [[x, y] for x in n1 for y in n2]
print(result)






