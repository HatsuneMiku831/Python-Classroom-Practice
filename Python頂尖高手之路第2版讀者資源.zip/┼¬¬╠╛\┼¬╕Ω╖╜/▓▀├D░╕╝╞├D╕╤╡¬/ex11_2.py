# ex11_1.py
def mymax(n1, n2):
    """ 較大值設計 """
    if n1 > n2:
        print("較大值是 : ", n1)
    else:
        print("較大值是 : ", n2)
        
x1, x2 = eval(input("請輸入2個數值 = "))
mymax(x1, x2)




