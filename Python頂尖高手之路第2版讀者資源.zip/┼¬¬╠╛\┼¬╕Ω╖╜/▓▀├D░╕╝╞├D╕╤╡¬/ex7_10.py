# ex7_10.py
n = 10
for i in range(1,n):
    for j in range(1,n-i+1):
        print(j, end='')
    print()




