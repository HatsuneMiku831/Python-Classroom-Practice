# ex13_8.py
import sys

print("目前Python版本是:     ", sys.version)
print("目前Python版本是:     ", sys.version_info)
print("目前Python平台是:     ", sys.platform)
print("目前Python視窗版本是: ", sys.getwindowsversion())
print("目前Python可執行檔路徑", sys.executable)




